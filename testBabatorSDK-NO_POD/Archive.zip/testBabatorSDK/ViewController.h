//
//  ViewController.h
//  testBabatorSDK
//
//  Created by Eliza Sapir on 16/05/2016.
//  Copyright © 2016 Babator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

